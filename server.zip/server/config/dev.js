//dev.js
module.exports = {
  googleClientID: '452926095292-0l5dfm35b0tgn57d4m948n5plbmnldq5.apps.googleusercontent.com',
  googleClientSecret: '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',
  mongoURI: 'mongodb+srv://emaily-dev:Kong1352431430.@cluster0.y2hggw4.mongodb.net/emaily-dev?retryWrites=true&w=majority',
  cookieKey: 'redacted',
  stripePublishableKey: 'pk_test_51MHIqKLk5bplKsoYuxMNjWLVymvJjDzI9LghV7IKHEqPH93irJ6KbaZcKPZ3vFaSkHQLhd0FvVnOrXWcqnImXyYl007B6CXVEI',
  stripeSecretKey: 'sk_test_51MHIqKLk5bplKsoYLG5MbWEes1qiIlDpQkod79bFZxhD4OAiJG9lcX3WBJFhiMTeuUBi68oNRP2K5l5qQlv8dGOc00Iemy57yV',
  sendGirdKey: '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',
  redirectDomain: 'http://localhost:3000'
};